﻿# Mappings

Cases → Invariants → Failure Modes
