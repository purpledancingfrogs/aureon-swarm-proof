﻿import runpy

if __name__ == '__main__':
    runpy.run_module(
        'intel_firewall_engine.engine.example_firewall_run',
        run_name='__main__'
    )
