def decompose(): return {'time_to_clarity_seconds': 0.0, 'coverage': {'variables': 9, 'constraints': 3, 'failure_modes': 2}}
