Case: Strategic Threat Forecast

Observed variables:
- Fragmentary signals
- Conflicting reports

Controllable variables:
- Collection prioritization

Constraints:
- Time pressure
- Source reliability

Outcome:
- High-confidence misprediction driven by narrative substitution
