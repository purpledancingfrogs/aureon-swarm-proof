﻿This directory contains verbatim model outputs.
No normalization.
No scoring.
No interpretation.
