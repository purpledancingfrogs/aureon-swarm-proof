﻿# Failure Modes

Each invariant violation maps to a predictable failure mode.
