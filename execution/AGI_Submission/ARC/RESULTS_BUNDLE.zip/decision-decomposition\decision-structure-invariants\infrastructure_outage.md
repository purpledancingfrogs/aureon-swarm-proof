Case: Regional Power Grid Failure

Observed variables:
- Load imbalance
- Weather conditions

Controllable variables:
- Load shedding policy

Constraints:
- Transformer capacity
- Interconnection dependencies

Outcome:
- Cascading outage due to hidden constraints
